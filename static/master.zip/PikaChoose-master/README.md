[Permalink](https://raw.github.com/jeremyfry/PikaChoose/master/readme.html "Permalink to PikaChoose Readme")

PikaChoose is jQuery gallery plugin to make slideshows simply and easily. Documentation and options can be found at: [PikaChoose.com][1]


 [1]: http://www.pikachoose.com